/***********************************************************************
* Program:
*    Project 2 Header, Skeet
*    Jared Wrathall, CS165
* Author:
*    JARED WRATHALL
************************************************************************/

#include <string>
#include <iostream>
#include <cassert>
#include <stdlib.h>
#include "uiInteract.h"  // interface with OpenGL   
#include "point.h"       // the ball has a position
#include "uiDraw.h"      // all the draw primitives exist here
#include <vector>

using namespace std;

/****************************************
 * SKEET
 *  Main skeet class
 ***************************************/
class Vector
{
  public:
   Point point;
   float dx;
   float dy;
  private:

};

class Rifle
{
   public:
   Rifle();
   void move(int up, int down);
   void draw();
   int getAngle() {return angle;};
   
  private:
   int angle;

};


class Bird
{
  public:
   void advance();
   void regen();
   void draw();
   void kill();
   bool getIsDead() { return isDead; };

  private:
   Vector vector;
   bool isDead;
   
   
};

class Bullet
{
  public:
   Bullet();
   void draw();
   void advance();
   void fire(int angle);
   bool getIsDead() { return isDead; };

  private:
   Vector vector;
   bool isDead;
   
   
  
};

class Score
{
  public:
   void draw();
   void advance();
   
  private:
   Vector vector;
  
   bool isDead;

};

class Skeet
{
  public:
   Skeet();
   void draw();
   void interact(const Interface *pUI);
   void advance();
   void minDist();
   // int minimumDistance(bird.vector.point, bullet[].vector.point);

  private:
   //Point point;
   Rifle rifle;
   Bird bird;
   Bullet bullet[5];
   Score score;
   vector <int> numBullets;
};




