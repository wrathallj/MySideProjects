/***********************************************************************
* Program:
*    Project 2, Skeet
*    Brother Helfrich, CS165
* Author:
*    Jared Wrathall
* Summary: 
*    
*    Estimated:  25.0 hrs   
*    Actual:     0.0 hrs
*      Please describe briefly what was the most difficult part
************************************************************************/

#include <iostream>
#include <cassert>
#include "skeet.h"     
#define deg2rad(value) ((M_PI / 180) * (value))

/*************************************************
 * Skeet :: CONSTRUCTOR
 ************************************************/
Skeet::Skeet() 
{
  
}

/*************************************************
 * SKEET : INTERACT
 * User interactions
 ************************************************/
void Skeet::interact(const Interface *pUI)
{
   // move the rifle if up is pressed or down
   rifle.move(pUI->isUp(), pUI->isDown());     

   // check what bullets are dead
   for (int i = 0; i < numBullets.size(); i++)
      if (bullet[i].getIsDead())
         numBullets.pop_back();
   
   // check if space is pressed
   if (pUI->isSpace())
   {
      // add to the amount of bullets on screen
      numBullets.push_back(1);
      
      // make sure there are no more than 5 bullets on screen
      if (numBullets.size() <= 5)
      {
         for (int i = 0; i < numBullets.size(); i++)
            if (bullet[i].getIsDead())
               bullet[i].fire(rifle.getAngle());
      }
   }
}

/**************************************************
 *SKEET : ADVANCE
 *************************************************/
void Skeet :: advance()
{
     
   bird.advance();
   for (int i = 0; i < 5; i++)
   {
      if (bullet[i].getIsDead() == false)
         bullet[i].advance();
   }
   score.advance();
}

/*************************************************
 * SKEET : DRAW
 * Draw the stuff
 ************************************************/
void Skeet::draw()
{
   rifle.draw();     
     
}

/*************************************************
 * Rifle :: CONSTRUCTOR
 ************************************************/
Rifle::Rifle() 
{
   angle = 45;
  
}

/*************************************************
 * Rifle : DRAW
 * Draw the stuff
 ************************************************/
void Rifle::draw()
{
   Point rifle;
   rifle.setX(rifle.getXMax() - 1.0); 
   rifle.setY(rifle.getYMin() + 1.0); 
   drawRect(rifle, 4, 20 * 2, angle);
}

/***************************************************
 *RIFLE : MOVE
 *
 **************************************************/
void Rifle :: move(int up, int down)
{
   
   if (up && (angle > 0))
   {
      angle -= (up + 9) / 5;
      
   }
   if (down && (angle < 90))
   {
      angle += (down + 9) / 5;
   }
   cout << angle << endl;
}
/*************************************************
 * BIRD :: CONSTRUCTOR
 ************************************************/

/*************************************************
 * BIRD : DRAW
 * Draw the stuff
 ************************************************/
void Bird::draw()
{
   vector.point.addX(vector.dx); 
   vector.point.addY(vector.dy);
   drawCircle(vector.point, 12, 20 * 2, 0);
}

/**************************************************
 *BIRD : ADVANCE
 *************************************************/
void Bird :: advance()
{
   if (isDead == true)
   {
      regen();
      isDead = false;
   }
   if (vector.point.getX() > 120 )
      isDead = true;
   else
      draw();
   
}

/*************************************************
 * BIRD : REGEN
 * Draw the stuff
 ************************************************/
void Bird::regen()
{
   vector.point.setX(-128); 
   vector.point.setY(random(-100,100)); 
  
   vector.dx = random(3,6);
   if ( vector.point.getY() > 0)
      vector.dy = random(-4,0);
   else
      vector.dy = random(0,4);
         
   drawCircle(vector.point, 12, 20 * 2, 0);
   
}

/**************************************************
 *BIRD : KILL
 *************************************************/
void Bird :: kill()
{

}

/*************************************************
 * BULLET : DRAW
 * Draw the stuff
 ************************************************/
void Bullet::draw()
{
   vector.point.addX(vector.dx); 
   vector.point.addY(vector.dy);
   drawDot(vector.point);
}

/***********************************************
 *
 *
 **********************************************/
void Bullet :: advance()
{
   
   draw();
   if (vector.point.getX() < -128 || vector.point .getY() > 128)
   {
      isDead = true;
      
   }
}

Bullet :: Bullet()
{
   isDead = true;
}

/***********************************************
 *
 *
 **********************************************/
void Bullet::fire(int angle)
{
   
   int speedBullet = 10;
   vector.point.setX(127);   
   vector.point.setY(-127);
   vector.dx = -sin (deg2rad(angle)) * speedBullet;
   vector.dy = cos(deg2rad(angle)) * speedBullet;
   isDead = false;
  
  
} 

/**********************************************
 *VECTOR : DISTANCE
 *
 *********************************************
int Skeet :: minimumDistance(Point a, Point b)
{
   float slice = 1/128;
   for (float per = 0; per == 1 per += slice)
      float distancedSquared = pow(((a.x + a.dx * per) - (b.x + b.dx * per)), 2)
         + pow(((a.y + a.dy * per) - (b.y + b.dy * per)), 2);
   minDist = 1
         
      return minDist;
}
/
/**********************************************
*VECTOR : DISTANCE
*
*********************************************/
 void Score :: advance()
 {
    draw();
 }

/**********************************************
*VECTOR : DISTANCE
*
*********************************************/
 void Score :: draw()
 {
    vector.point.setX(-128); 
    vector.point.setY(125);
    drawNumber(vector.point,1);
    // vector2.point.setX(128);
    //vector2.point.setY(128);
    // drawNumber(vector2.point,1);
 }

/***********************
 *
 *
 *************************
void Skeet :: minDist()
{
   for (int i = 0; i < 5; i++)
   {
      int dx = bird.vector.dx - bullet.vector.dx;
      int dy = bird.vector.dy - bullet.vector.dy;
      int minDist = (dx * dx) + (dy * dy);
      if (minDist < 10)
      {
         bird.isDead = true;
         for (int i = 0; i < 5; i++)
            bullet[i].isDead = true;
      }
   }
   return;
}
*/

 /************
  *
  *
  ********/
